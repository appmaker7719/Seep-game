package com.example.seepgame;

import android.app.*; import android.os.*; import android.graphics.Color; import android.view.*; import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
 LinearLayout root, hand; TextView table, score, msg; int mode=2, turn=0; ArrayList<Card> deck=new ArrayList<>(), cards=new ArrayList<>(), tableCards=new ArrayList<>(); int[] scores=new int[4];
 String[] suits={"♠","♥","♦","♣"}, ranks={"A","2","3","4","5","6","7","8","9","10","J","Q","K"};
 static class Card { String s,r; int v; Card(String s,String r,int v){this.s=s;this.r=r;this.v=v;} public String toString(){return r+s;} }
 int val(String r){ if(r.equals("A"))return 1;if(r.equals("J"))return 11;if(r.equals("Q"))return 12;if(r.equals("K"))return 13;return Integer.parseInt(r); }

 public void onCreate(Bundle b){super.onCreate(b); build(); setMode(2);}
 TextView tv(String s,int z){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(Color.WHITE);t.setPadding(12,10,12,10);return t;}
 void build(){
  root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(12,12,12,12);root.setBackgroundColor(Color.rgb(7,92,59));
  root.addView(tv("🃏 SEEP — 2 / 4 PLAYER",22));
  LinearLayout modes=new LinearLayout(this); Button b2=new Button(this);b2.setText("2 Player");Button b4=new Button(this);b4.setText("4 Player");
  modes.addView(b2,new LinearLayout.LayoutParams(0,60,1));modes.addView(b4,new LinearLayout.LayoutParams(0,60,1));root.addView(modes);
  b2.setOnClickListener(v->setMode(2)); b4.setOnClickListener(v->setMode(4));
  score=tv("",16);root.addView(score);
  table=tv("",18);table.setGravity(Gravity.CENTER);table.setBackgroundColor(Color.rgb(10,112,72));root.addView(table,new LinearLayout.LayoutParams(-1,120));
  msg=tv("",15);root.addView(msg);
  Button ng=new Button(this);ng.setText("New Game");ng.setOnClickListener(v->newGame());root.addView(ng);
  ScrollView sv=new ScrollView(this);hand=new LinearLayout(this);hand.setOrientation(LinearLayout.HORIZONTAL);hand.setGravity(Gravity.CENTER);sv.addView(hand);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
  setContentView(root);
 }
 void setMode(int m){mode=m;newGame();}
 void newGame(){
  deck.clear();cards.clear();tableCards.clear();Arrays.fill(scores,0);turn=0;
  for(String s:suits)for(String r:ranks)deck.add(new Card(s,r,val(r)));
  Collections.shuffle(deck); for(int i=0;i<13;i++)cards.add(deck.remove(deck.size()-1));
  msg.setText(mode+" Player game started. Your turn.");render();
 }
 void render(){
  score.setText("You: "+scores[0]+"    "+(mode==4?"Computer 1: "+scores[1]+"   Computer 2: "+scores[2]+"   Computer 3: "+scores[3]:"Computer: "+scores[1]));
  table.setText("TABLE\n"+(tableCards.size()==0?"—":tableCards.toString()));
  hand.removeAllViews();
  for(int i=0;i<cards.size();i++){final int k=i;Button b=new Button(this);b.setText(cards.get(i).toString());b.setTextSize(18);
   if(cards.get(i).s.equals("♥")||cards.get(i).s.equals("♦"))b.setTextColor(Color.RED);
   b.setOnClickListener(v->play(k));hand.addView(b,new LinearLayout.LayoutParams(100,130));}
 }
 void play(int i){
  if(turn!=0){msg.setText("Computer ki turn hai.");return;}
  Card c=cards.remove(i);tableCards.add(c);scores[0]+=c.v;turn=1;msg.setText("Tumne "+c+" khela.");render();
  if(mode>1)new Handler().postDelayed(()->computer(),600);
 }
 void computer(){
  if(turn==0)return;if(cards.isEmpty()){msg.setText("Round complete!");return;}
  Card c=cards.remove((int)(Math.random()*cards.size()));tableCards.add(c);scores[turn]+=c.v;msg.setText("Computer "+turn+" ne "+c+" khela.");
  turn++;if(turn>=mode)turn=0;render();if(turn!=0)new Handler().postDelayed(()->computer(),600);
 }
}